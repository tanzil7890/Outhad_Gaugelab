MODELS=(
    "/path/to/your/model"
)

python ragtruth.py --models "${MODELS[@]}"