## Repository for Judgment Datatypes

This repository contains the datatypes for [judgeval](https://github.com/JudgmentLabs/judgeval/).